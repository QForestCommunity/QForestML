import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="QForestML",
    version="0.0.1",
    author="Sashwat Anagolum",
    author_email="sashwat.anagolum@gmail.com",
    description="A wrapper for machine learning models in Qiskit.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/QForestCommunity/QForestML",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)