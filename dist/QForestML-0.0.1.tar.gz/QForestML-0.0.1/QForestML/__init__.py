name = "QForestML"

from . import qnn
